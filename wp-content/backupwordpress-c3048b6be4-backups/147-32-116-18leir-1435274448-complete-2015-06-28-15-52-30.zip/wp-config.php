<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'leir');
define('FS_METHOD', 'direct');
/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'heaven');

define('WP_HOME','http://147.32.116.18/leir/');
define('WP_SITEURL','http://147.32.116.18/leir/');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '}?CO+3U7)$niPrD2B#iM(0%)5vL1_ .O2|x|^kyA!YYII`o-ei|ncV6}zpEO{/o/');
define('SECURE_AUTH_KEY',  '1O$0w[dwNpQC{$lbXs7-Ftw$x@Z>phIv tl+EHSX7+ZalmRqN+;B0f=&$Mo#dfwL');
define('LOGGED_IN_KEY',    '=!QL_V%dEMtHz2C|-}iCabf%m6*:GM]-g[||xR>UkIl?+Y-hdN|mpaF[:)Zs%|p ');
define('NONCE_KEY',        'BWC-pK:;u`DEjaIR2}p%G0/mvM4BN[wT|TP#|$E>g_~8FYZU6HcPi+@i|^)jI~-V');
define('AUTH_SALT',        'pp+Bd~Ni~Xw]LyiobQfq|GTU0Dzu;T31cJ:v6{8TsR`G@*MIDQp=e=XA6/;Dp(Eq');
define('SECURE_AUTH_SALT', 'xo0#|5T,F1@N1iL<.(N+^J,Cb9.{NNfOX(U53;+e-$jMqD|5%>;#ok&8N0~hme]T');
define('LOGGED_IN_SALT',   'r>/y&D!^l-%vkvijd4Eb>&vytk)-M{m[ehoIQn5j2%C&eH|30H$ Pi/)*q<tJYlP');
define('NONCE_SALT',       'Pf7q^V%U*[RG=I(8h:u+T^B_Y4+I?_h/*@``,[g7{!yEK8mv~:?@I^a;QJwC |0 ');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
